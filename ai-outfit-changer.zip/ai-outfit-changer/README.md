# 🎨 AI 换装系统

上传人像照片，描述想要的服装，AI 自动帮你换装！

---

## 🚀 快速开始

### 1. 获取 Fal.ai API Key

访问：https://fal.ai/dashboard/keys

- 注册/登录账号
- 创建新的 API Key
- 复制 Key

### 2. 配置 API Key

在项目目录创建 `.env` 文件：

```bash
cd D:\ai-outfit-changer
notepad .env
```

添加内容：
```
FAL_KEY=你的_fal_key_在这里
```

### 3. 启动服务

```bash
node server.js
```

### 4. 打开浏览器

访问：http://localhost:3001

---

## 📁 项目结构

```
D:\ai-outfit-changer\
├── server.js          # 后端服务器
├── package.json       # 项目配置
├── .env              # API 配置（需自行创建）
├── .env.example      # 配置示例
├── uploads/          # 上传的图片
├── history.json      # 历史记录
└── public/
    └── index.html     # 前端页面
```

---

## ✨ 功能特点

- 📸 拖拽上传人像照片
- 👔 自定义服装描述
- ⚡ 快速风格选择（西装、休闲、礼服等）
- 🎭 实时预览原图和结果
- 📜 历史记录保存
- 📱 响应式设计

---

## 🎯 使用技巧

### 服装描述示例

```
- a red formal suit with tie, professional business attire
- casual white t-shirt and blue jeans
- elegant black evening dress
- traditional chinese tang suit
- wedding dress, white, romantic
- superhero costume, marvel style
- medieval knight armor
```

### 提示

- 描述越详细，效果越好
- 可以指定颜色、风格、场合
- 英文描述效果更佳

---

## ⚠️ 注意事项

1. **API 费用**: Fal.ai 按使用量计费，新用户有免费额度
2. **图片大小**: 最大 10MB
3. **处理时间**: 通常 10-30 秒
4. **隐私**: 图片仅用于处理，不会存储到云端

---

## 🛠️ 技术栈

- **后端**: Node.js + Express
- **AI**: Fal.ai (Flux 模型)
- **前端**: 原生 HTML/CSS/JS
- **上传**: Multer

---

## 📞 问题排查

### 未配置 API Key
- 检查 `.env` 文件是否存在
- 确认 `FAL_KEY` 格式正确

### 处理失败
- 检查网络连接
- 确认 Fal.ai 账户有余额
- 尝试更清晰的图片

### 效果不理想
- 使用更详细的服装描述
- 确保人像清晰可见
- 尝试不同的风格提示词

---

**Enjoy! 🎉**
