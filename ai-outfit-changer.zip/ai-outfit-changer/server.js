const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const app = express();
const PORT = 3001;

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 文件上传配置
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});

const upload = multer({ 
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype);
    cb(null, ext && mime);
  }
});

// Fal.ai API 配置
const FAL_KEY = process.env.FAL_KEY || '';

// 换装函数 - 使用 Fal.ai 的图像编辑 API
async function changeOutfit(imageUrl, outfitDescription) {
  if (!FAL_KEY) {
    throw new Error('未配置 FAL_KEY，请在 .env 文件中设置 Fal.ai API Key');
  }

  try {
    // 使用 Fal.ai 的图像到图像生成
    const response = await fetch('https://fal.run/fal-ai/flux/dev/image-to-image', {
      method: 'POST',
      headers: {
        'Authorization': `Key ${FAL_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        image_url: imageUrl,
        prompt: `person wearing ${outfitDescription}, high quality, detailed, realistic`,
        strength: 0.75,
        num_inference_steps: 28,
        guidance_scale: 3.5
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Fal.ai API 错误：${error}`);
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Fal.ai 调用失败:', error);
    throw error;
  }
}

// ==================== API 路由 ====================

// 上传并换装
app.post('/api/change-outfit', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: '请上传图片' });
    }

    const { outfit } = req.body;
    if (!outfit) {
      return res.status(400).json({ success: false, error: '请描述想要换的服装' });
    }

    // 构建图片 URL（本地服务器）
    const imageUrl = `http://localhost:${PORT}/uploads/${req.file.filename}`;

    console.log('📸 收到换装请求:', {
      file: req.file.filename,
      outfit: outfit
    });

    // 调用 Fal.ai API
    const result = await changeOutfit(imageUrl, outfit);

    res.json({
      success: true,
      data: {
        original: imageUrl,
        result: result.images?.[0]?.url || result.image?.url,
        falResult: result
      }
    });

  } catch (error) {
    console.error('换装失败:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message,
      tip: '请确保已配置有效的 FAL_KEY'
    });
  }
});

// 获取历史记录
app.get('/api/history', (req, res) => {
  try {
    const historyFile = path.join(__dirname, 'history.json');
    if (fs.existsSync(historyFile)) {
      const history = JSON.parse(fs.readFileSync(historyFile, 'utf-8'));
      res.json({ success: true, data: history });
    } else {
      res.json({ success: true, data: [] });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 保存历史记录
function saveHistory(record) {
  const historyFile = path.join(__dirname, 'history.json');
  let history = [];
  if (fs.existsSync(historyFile)) {
    history = JSON.parse(fs.readFileSync(historyFile, 'utf-8'));
  }
  history.unshift({
    ...record,
    timestamp: new Date().toISOString()
  });
  // 只保留最近 50 条
  history = history.slice(0, 50);
  fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));
}

// 测试 API
app.get('/api/test', (req, res) => {
  res.json({ 
    success: true, 
    message: 'AI 换装服务运行正常',
    falKeyConfigured: !!FAL_KEY
  });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`\n🎨 AI 换装系统运行在 http://localhost:${PORT}`);
  console.log(`📁 上传目录：${uploadDir}`);
  console.log(`🔑 Fal.ai Key: ${FAL_KEY ? '已配置 ✅' : '未配置 ❌'}`);
  console.log(`\n💡 获取 Fal.ai API Key: https://fal.ai/dashboard/keys\n`);
});
