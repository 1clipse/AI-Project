const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// 数据文件路径
const DATA_FILE = path.join(__dirname, 'data.json');

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 初始化数据
function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
    }
  } catch (e) {
    console.error('加载数据失败:', e.message);
  }
  return { users: [], records: [] };
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// 初始化数据文件
let db = loadData();
if (db.users.length === 0 && db.records.length === 0) {
  saveData(db);
  console.log('✅ 数据文件已初始化');
}

// ==================== API 路由 ====================

// 获取所有员工
app.get('/api/users', (req, res) => {
  try {
    db = loadData();
    res.json({ success: true, data: db.users });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 添加员工
app.post('/api/users', (req, res) => {
  try {
    db = loadData();
    const { name, employee_id, department } = req.body;
    
    if (!name || !employee_id) {
      return res.status(400).json({ success: false, error: '姓名和工号必填' });
    }
    
    // 检查工号是否已存在
    if (db.users.find(u => u.employee_id === employee_id)) {
      return res.status(400).json({ success: false, error: '工号已存在' });
    }
    
    const newUser = {
      id: Date.now(),
      name,
      employee_id,
      department: department || '',
      created_at: new Date().toISOString()
    };
    
    db.users.push(newUser);
    saveData(db);
    
    res.json({ success: true, data: newUser });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 删除员工
app.delete('/api/users/:id', (req, res) => {
  try {
    db = loadData();
    db.users = db.users.filter(u => u.id != req.params.id);
    saveData(db);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 打卡
app.post('/api/attendance/check', (req, res) => {
  try {
    db = loadData();
    const { employee_id, type } = req.body;
    
    if (!employee_id || !type) {
      return res.status(400).json({ success: false, error: '参数不完整' });
    }
    
    const user = db.users.find(u => u.employee_id === employee_id);
    if (!user) {
      return res.status(404).json({ success: false, error: '员工不存在' });
    }
    
    const today = new Date().toISOString().split('T')[0];
    const now = new Date().toLocaleString('zh-CN');
    
    let record = db.records.find(r => r.user_id === user.id && r.date === today);
    
    if (!record) {
      // 创建新记录
      if (type === 'check_in') {
        record = {
          id: Date.now(),
          user_id: user.id,
          date: today,
          check_in: now,
          check_out: null,
          status: 'normal',
          note: ''
        };
        db.records.push(record);
        saveData(db);
        res.json({ success: true, data: { action: '签到成功', time: now } });
      } else {
        res.status(400).json({ success: false, error: '请先签到' });
      }
    } else {
      // 更新记录
      if (type === 'check_in' && record.check_in) {
        res.status(400).json({ success: false, error: '今天已经签到过了' });
      } else if (type === 'check_out' && record.check_out) {
        res.status(400).json({ success: false, error: '今天已经签退过了' });
      } else if (type === 'check_out') {
        record.check_out = now;
        saveData(db);
        res.json({ success: true, data: { action: '签退成功', time: now } });
      } else {
        res.status(400).json({ success: false, error: '无效操作' });
      }
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 获取打卡记录
app.get('/api/attendance/records', (req, res) => {
  try {
    db = loadData();
    const { user_id, start_date, end_date } = req.query;
    
    let records = db.records.map(r => {
      const user = db.users.find(u => u.id === r.user_id);
      return {
        ...r,
        name: user ? user.name : '未知',
        employee_id: user ? user.employee_id : '未知',
        department: user ? user.department : ''
      };
    });
    
    // 过滤
    if (user_id) records = records.filter(r => r.user_id == user_id);
    if (start_date) records = records.filter(r => r.date >= start_date);
    if (end_date) records = records.filter(r => r.date <= end_date);
    
    // 排序
    records.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    res.json({ success: true, data: records });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 获取统计信息
app.get('/api/attendance/stats', (req, res) => {
  try {
    db = loadData();
    const { start_date, end_date } = req.query;
    
    let records = db.records;
    if (start_date) records = records.filter(r => r.date >= start_date);
    if (end_date) records = records.filter(r => r.date <= end_date);
    
    const stats = db.users.map(user => {
      const userRecords = records.filter(r => r.user_id === user.id);
      return {
        id: user.id,
        name: user.name,
        employee_id: user.employee_id,
        department: user.department,
        total_days: userRecords.length,
        check_in_days: userRecords.filter(r => r.check_in).length,
        check_out_days: userRecords.filter(r => r.check_out).length
      };
    });
    
    stats.sort((a, b) => a.name.localeCompare(b.name));
    
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`\n🚀 考勤系统服务器运行在 http://localhost:${PORT}`);
  console.log(`📊 打开浏览器访问：http://localhost:${PORT}`);
  console.log(`💾 数据保存在：${DATA_FILE}\n`);
});
